/*
 * hexfile.h
 *
 *  Created on: 2011-12-24
 *      Author: wengkai
 */

#ifndef HEXFILE_H_
#define HEXFILE_H_

#include "memmap.h"

int readHexFile(char* fileName, MemMap *mp);

#endif /* HEXFILE_H_ */
