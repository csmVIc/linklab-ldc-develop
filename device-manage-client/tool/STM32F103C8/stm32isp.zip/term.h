/*
 * term.h
 *
 *  Created on: 2012-1-5
 *      Author: wengkai
 */

#ifndef TERM_H_
#define TERM_H_

int term(char* portName, int baud, int bootp, int reset, int isEcho, int isLineEdit);

#endif /* TERM_H_ */
