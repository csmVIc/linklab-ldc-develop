#!/bin/bash

(msp430-objcopy $BURNFILE -O ihex $BURNFILE.ihex) && (./tool/TelosB/msp430-bsl-linux --telosb -c $DEVPORT -r) && (./tool/TelosB/msp430-bsl-linux --telosb -c $DEVPORT -e) && (./tool/TelosB/msp430-bsl-linux --telosb -c $DEVPORT -I -p $BURNFILE.ihex) && (rm $BURNFILE.ihex)
